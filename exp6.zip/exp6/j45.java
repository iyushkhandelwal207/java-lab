// e) Write a Java Program that Show the Implementation of Interface 
class j45 {
    public static void main(String[] args){
        Circle c1=new Circle();
        c1.draw();
    }
}
interface Drawable {
    void draw(); 
}

class Circle implements Drawable {
    public void draw() {
        System.out.println("Drawing a circle");
    }
}