// Write a Java Program to Use Super Keyword in Inheritance Class
class j42 {
    public static void main(String[] args){
        Dog d1=new Dog("Tommy",12,4);
        d1.toprint();
    }
}
class Animal{
    int height;
    String name;
    Animal(String name,int height){
        this.height=height;
       this.name=name;
    }
}
class Dog extends Animal{
    int legs;
    Dog(String name,int height,int legs){
        super(name,height);
        this.legs=legs;
    }
    void toprint(){
        System.out.println("height:"+this.height);
        System.out.println("Name:"+this.name);
        System.out.println("legs:"+this.legs);
    }
}
// output - height:12
// Name:Tommy
// legs:4
