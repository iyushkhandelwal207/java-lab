// d) Write a Java Program to Access Super Class in a Method Overriding
class j44 {
    public static void main(String[] args){
        Student s1=new Student();
        s1.setinfo("radha",18, 10);
        s1.printinfo();
    }   
}
class Human{
    String name;
    int age;
    void setinfo(String name,int age){
        this.name=name;
        this.age=age;
    }
    void printinfo(){
        System.out.println("name:"+this.name);
        System.out.println("age:"+this.age);
    }
}
class Student extends Human{
    int id;
    void setinfo(String name,int age,int id){
       super.setinfo(name, age);
        this.id=id;
    }
    void printinfo(){
        super.printinfo();
        System.out.println("id:"+this.id);
    }
}
