// Write a Java Program to Use This Keyword in Inheritance Class 
import java.util.*;
import java.lang.*;
class j41{
    public static void main(String[] args){
        Dog d1=new Dog("doggy",12,4);
        d1.toprint();
    }
}
class Animal{
    protected int height;
    protected String name;
}
class Dog extends Animal{
    int legs;
    Dog(String name,int height,int legs){
        this.height=height;
        this.name=name;
        this.legs=legs;
    }
    void toprint(){
        System.out.println("height:"+this.height);
        System.out.println("Name:"+this.name);
        System.out.println("legs:"+this.legs);
    }
}
// output - height:12
// Name:doggy
// legs:4