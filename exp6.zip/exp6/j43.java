// c) Write a Java Program to Display Method Overriding in a Class using Inheritance  Class
class j43 {
public static void main(String[] args){
Student s1=new Student();
s1.get();
}
}
class Human{
    void get(){
        System.out.println("every human can think.......");
    }
}
class Student extends  Human{
    void get(){
        System.out.println("every student can think creative......");
    }
}