// e) Write a Java Program for Exception Handling using finally block

public class j50 {
    public static void main(String[] args) {
        try {
            int a = 20, b = 0;
            int result = a / b;  // Causes ArithmeticException
            System.out.println("Result: " + result);
        } catch (ArithmeticException e) {
            System.out.println("Exception caught: " + e.getMessage());
        } finally {
            System.out.println("Finally block executed. This block runs whether exception occurs or not.");
        }
    }
}

// Output:
// Exception caught: / by zero
// Finally block executed. This block runs whether exception occurs or not.
