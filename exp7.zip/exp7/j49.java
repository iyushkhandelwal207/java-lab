// d) Write a Java Program for Array Index Out Of Bounds Exception

public class j49 {
    public static void main(String[] args) {
        try {
            int[] arr = {1, 2, 3};
            System.out.println("Accessing element at index 5: " + arr[5]);  // Causes exception
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Array Index Out Of Bounds Exception caught: " + e.getMessage());
        }
    }
}

// Output:
// Array Index Out Of Bounds Exception caught: Index 5 out of bounds for length 3
