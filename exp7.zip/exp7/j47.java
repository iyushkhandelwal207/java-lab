// b) Write a Java Program for Null Pointer Exception

public class j47 {
    public static void main(String[] args) {
        try {
            String str = null;
            System.out.println("String length: " + str.length());  // Causes NullPointerException
        } catch (NullPointerException e) {
            System.out.println("Null Pointer Exception caught: " + e.getMessage());
        }
    }
}

// Output:
// Null Pointer Exception caught: null
