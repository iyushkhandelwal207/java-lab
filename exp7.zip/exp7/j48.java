// c) Write a Java Program for Number Format Exception

public class j48 {
    public static void main(String[] args) {
        try {
            String numStr = "abc";
            int number = Integer.parseInt(numStr);  // Causes NumberFormatException
            System.out.println("Converted number: " + number);
        } catch (NumberFormatException e) {
            System.out.println("Number Format Exception caught: " + e.getMessage());
        }
    }
}

// Output:
// Number Format Exception caught: For input string: "abc"
