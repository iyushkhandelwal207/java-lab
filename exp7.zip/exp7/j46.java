// a) Write a Java Program for Arithmetic Exception

public class j46 {
    public static void main(String[] args) {
        try {
            int a = 10;
            int b = 0;
            int result = a / b;  // This line will throw ArithmeticException
            System.out.println("Result: " + result);
        } catch (ArithmeticException e) {
            System.out.println("Arithmetic Exception caught: " + e.getMessage());
        }

        System.out.println("Program continues after exception handling.");
    }
}

// Output:
// Arithmetic Exception caught: / by zero
// Program continues after exception handling.
