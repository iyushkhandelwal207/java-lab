//d) Write a Java Program to implement recursion (factorial of a number) 

class j38{
static int fact(int n){
	if(n==1||n==0){
		return 1;
	}
	else{
		return (n*fact(n-1));
	}
}
public static void main(String[] args){
	int result=fact(5);
	System.out.println("o/p:"+result);
}
};