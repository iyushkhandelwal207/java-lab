//b) Write a Java Program to Reverse Each Word in a String 
import java.util.Scanner;
class j36 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a string: ");
        String s = sc.nextLine(); 
        String[] words = s.split(" "); 
        String result = "";
		for (String word : words) {
            char[] ch = word.toCharArray(); 
            int len = ch.length;
			for (int i = 0; i < len / 2; i++) {
                char temp = ch[i];
                ch[i] = ch[len - i - 1];
                ch[len - i - 1] = temp;
            }
            result += new String(ch) + " ";
        }
        System.out.println("Reversed string: " + result.trim());
        sc.close();
    }
}
