//c) Write a Java Program to explain the concept of Callby value and Call by reference 
class j37{
static void callvalue(int a,int b){
int temp=a;
a=b;
b=temp;
}
static void callreference(int[] a){
int temp=a[0];
a[0]=a[1];
a[1]=temp;
}
public static void main(String[] args){
int a=5;
int b=6;
callvalue(a,b);
System.out.println("the callbyvalue:\n"+"a:"+a+"b:"+b);
int[] ref={5,6};
callreference(ref);
System.out.println("the callbyReference:\n"+"a:"+a+"b:"+b);
}
}