//a) Write a Java Program to Concatenate Two Strings 
class j35{
public static void main(String[] args){
	String s1="hello";
	String s2="world";
	String s3=s1+" "+s2;
	System.out.println("concatenated String:"+s3);
}
}