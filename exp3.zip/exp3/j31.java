//Write a Java Program to Find Sum and Average of All Elements in an Array 
class j31{
public static void main(String[] args){
int arr[]={1,2,3,4,5,6,7,8,9};
int sum=0;
for(int i=0;i<arr.length;i++){
sum=sum+arr[i];
}
int avg=sum/arr.length;
System.out.println("sum:"+sum);
System.out.println("avarage:"+avg);
}
}