//e) Write a Java Program to Separate Odd and Even Numbers from an Array 

class j34{
public static void main(String[] args){
int arr[]={1,2,3,4,5,6,7,8,9};
int odd[]=new int[arr.length];
int even[]=new int[arr.length];
int oddindex=0;
int evenindex=0;
for(int i=0;i<arr.length;i++){
	if(arr[i]%2==0){
		even[evenindex++]=arr[i];
	}
	else{
		odd[oddindex++]=arr[i];
	}

}
for(int i=0;i<oddindex;i++){
	System.out.println("it is odd:"+odd[i]);
}
for(int i=0;i<evenindex;i++){
	System.out.println("it is even:"+even[i]);
}
}
}
