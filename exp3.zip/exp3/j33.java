//d) Write a Java Program to Multiply Two Matrices 

import java.util.*;
class j33{
public static void main(String[] args){
	int arr1[][]=new int[2][2];
	int arr2[][]=new int[2][2];
	int arr[][]=new int[2][2];
	Scanner sc=new Scanner(System.in);
	Scanner s1=new Scanner(System.in);
	System.out.println("enter elements in arr1");
	for(int i=0;i<2;i++){
		for(int j=0;j<2;j++){
			arr1[i][j]=sc.nextInt();
		}
	}
	System.out.println("enter elements in arr2");
	for(int i=0;i<2;i++){
		for(int j=0;j<2;j++){
			arr2[i][j]=s1.nextInt();
		}
	}
	for(int i=0;i<2;i++){
		for(int j=0;j<2;j++){
			for(int k=0;k<2;k++){
				arr[i][j]+=arr1[i][k]*arr2[k][j];
			}
		}
	}
	for(int i=0;i<2;i++){
		for(int j=0;j<2;j++){
			System.out.print(arr[i][j]+" ");
		}
		System.out.println(" ");
	}
}
}
		
